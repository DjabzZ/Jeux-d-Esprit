﻿using System;
using System.Diagnostics;
using MySql.Data.MySqlClient;

namespace JeuxEsprit
{
    class Program
    {
        static void Main(string[] args)
        {
            // Connexion à la base de données
            ConnexionBaseDeDonnees();

            // Demande de nom, d'email et de pseudo
            Console.WriteLine("\nVeuillez vous connecter afin de pouvoir vous amuser\n");
            string nom;
            do
            {
                Console.Write("Nom: ");
                nom = Console.ReadLine();
                if (nom.Length < 3)
                {
                    Console.WriteLine("Le nom doit contenir au moins trois lettres. Veuillez réessayer.");
                }
            } while (nom.Length < 3); // Demande le nom jusqu'à ce qu'il contienne au moins 3 caractères

            string email;
            do
            {
                Console.Write("E-mail: ");
                email = Console.ReadLine();
                if (!IsValidEmail(email))
                {
                    Console.WriteLine("Adresse e-mail invalide. Veuillez saisir une adresse e-mail valide.");
                }
            } while (!IsValidEmail(email)); // Demande l'email jusqu'à ce qu'une adresse valide soit saisie

            string pseudo;
            do
            {
                Console.Write("Pseudo: ");
                pseudo = Console.ReadLine();
                if (pseudo == nom)
                {
                    Console.WriteLine("Le pseudo ne peut pas être le même que le nom. Veuillez en choisir un autre.");
                }
            } while (pseudo == nom); // Demande le pseudo jusqu'à ce qu'il soit différent du nom

            // Demande du statut (amateur ou professionnel)
            string statut;
            do
            {
                Console.Write("\nÊtes-vous un joueur amateur ou professionnel ? (A/P): ");
                statut = Console.ReadLine().ToUpper();
            } while (statut != "A" && statut != "P"); // Demande le statut jusqu'à ce qu'il soit "A" ou "P"

            Console.Clear(); // Efface le contenu précédent de la console

            Console.WriteLine("\nBienvenue dans le jeu d'esprit\n");

            // Insertion des informations du joueur dans la base de données
            ConnexionBaseDeDonnees(nom, email, pseudo, statut);

            // Choix du type de jeu
            Console.WriteLine("À quel type de jeu voulez-vous jouer ? :\n");
            Console.WriteLine("1. Cérébral");
            Console.WriteLine("2. Tactique");
            Console.WriteLine("3. Familial");
            Console.Write("\nVotre choix (1/2/3): ");
            int choix = Convert.ToInt32(Console.ReadLine());
            // Afficher le message "Bon choix !"
            Console.WriteLine("\nBon choix !\n");

            switch (choix)
            {
                case 1:
                    // Afficher les jeux cérébraux disponibles
                    Console.WriteLine("\nJeux cérébraux disponibles :\n");
                    Console.WriteLine("1. Chiffrement de Vigenère");
                    Console.WriteLine("2. Chiffrement de César");
                    Console.Write("\nVotre choix (1/2): ");
                    int jeuCerebral = Convert.ToInt32(Console.ReadLine());
                    switch (jeuCerebral)
                    {
                        case 1:
                            // Afficher le Chiffrement de Vigerère
                            Console.WriteLine("\nBonne chance ! Amusez-vous bien !:");
                            Console.WriteLine("\nLancement du jeu !:\n");
                            Console.Clear(); // Efface le contenu précédent de la console
                            // Lancement du Chiffrement de Vigenère
                            StartGame(@"C:\Users\footb\OneDrive\Cour BTS SIO\Cour\SLAM\Mme.PEYRATAUD\Projet et TP\JEUX D'ESPRIT\Jeux d'Esprit\Jeux Individuel\Chiffrement de Vigenère\Chiffrement de Vigenère\bin\Debug\net6.0");
                            break;
                        case 2:
                            // Afficher le Chiffrement de César
                            Console.WriteLine("\nBonne chance ! Amusez-vous bien !:");
                            Console.WriteLine("\nLancement du jeu !:\n");
                            Console.Clear(); // Efface le contenu précédent de la console
                            // Lancement du Chiffrement de César
                            StartGame(@"C:\Users\footb\OneDrive\Cour BTS SIO\Cour\SLAM\Mme.PEYRATAUD\Projet et TP\JEUX D'ESPRIT\Jeux d'Esprit\Jeux Individuel\Chiffrement de césar\Chiffrement de césar\bin\Debug\net6.0");
                            break;
                        default:
                            Console.WriteLine("Choix invalide.");
                            break;
                    }
                    break;
                case 2:
                    // Afficher le jeu tactique disponible
                    Console.WriteLine("\nJeu tactique disponible : Plus ou moins");
                    Console.WriteLine("\nBonne chance ! Amusez-vous bien !:");
                    Console.WriteLine("\nLancement du jeu :\n");
                    Console.Clear(); // Efface le contenu précédent de la console
                    // Lancement du jeu plus ou moins
                    StartGame(@"C:\Users\footb\OneDrive\Cour BTS SIO\Cour\SLAM\Mme.PEYRATAUD\Projet et TP\JEUX D'ESPRIT\Jeux d'Esprit\Jeux Individuel\Jeux plus ou moins\Jeux plus ou moins\bin\Debug\net6.0");
                    break;
                case 3:
                    // Afficher le jeu familial disponible
                    Console.WriteLine("\nJeu familial disponible : Le Pendu");
                    Console.WriteLine("\nBonne chance ! Amusez-vous bien !:");
                    Console.WriteLine("\nLancement du jeu :\n");
                    Console.Clear(); // Efface le contenu précédent de la console
                    // Lancement du jeu du Pendu
                    StartGame(@"C:\Users\footb\OneDrive\Cour BTS SIO\Cour\SLAM\Mme.PEYRATAUD\Projet et TP\JEUX D'ESPRIT\Jeux d'Esprit\Jeux Individuel\Jeu du pendu\Jeu du pendu\bin\Debug\net6.0");
                    break;
                default:
                    Console.WriteLine("Choix invalide.");
                    break;
            }

            Console.ReadLine(); // Pour éviter que la console se ferme immédiatement
        }

        static void ConnexionBaseDeDonnees()
        {
            // Chaîne de connexion MySQL
            string connectionString = "server=localhost;user=root;database=jeux_desprit;password=root";

            // Créer une connexion MySQL
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    // Ouvrir la connexion
                    connection.Open();
                    Console.WriteLine("\nConnexion à la base de données réussie !");
                }
                catch (Exception ex)
                {
                    // Gérer les erreurs de connexion
                    Console.WriteLine("\nErreur lors de la connexion à la base de données : " + ex.Message);
                }
            }
        }

        static void ConnexionBaseDeDonnees(string nom, string email, string pseudo, string statut)
        {
            // Chaîne de connexion MySQL
            string connectionString = "server=localhost;user=root;database=jeux_desprit;password=root";

            // Requête SQL pour obtenir le dernier numéro de joueur
            string lastPlayerQuery = "SELECT MAX(num_joueur) FROM Joueur";

            // Créer une connexion MySQL
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    // Créer une commande MySQL pour obtenir le dernier numéro de joueur
                    using (MySqlCommand lastPlayerCommand = new MySqlCommand(lastPlayerQuery, connection))
                    {
                        // Ouvrir la connexion
                        connection.Open();
                        Console.WriteLine("Connexion à la base de données réussie !");

                        // Exécuter la commande pour obtenir le dernier numéro de joueur
                        object lastPlayerResult = lastPlayerCommand.ExecuteScalar();
                        int lastPlayerNumber = lastPlayerResult != DBNull.Value ? Convert.ToInt32(lastPlayerResult) : 0;
                        int newPlayerNumber = lastPlayerNumber + 1;

                        // Déterminer la table dans laquelle insérer les informations du joueur
                        string tableToInsert = statut == "P" ? "Professionnel" : "Amateur";

                        // Requête SQL pour insérer le joueur dans la table correspondante
                        string query = $"INSERT INTO Joueur (num_joueur, nom_joueur, mail_joueur, avatar_joueur) VALUES (@num, @nom, @email, @pseudo)";
                        string insertQuery = $"INSERT INTO {tableToInsert} (num_joueur) VALUES (@num)";

                        // Créer une commande MySQL pour insérer le nouveau joueur
                        using (MySqlCommand command = new MySqlCommand(query, connection))
                        {
                            // Ajouter les paramètres à la commande
                            command.Parameters.AddWithValue("@num", newPlayerNumber);
                            command.Parameters.AddWithValue("@nom", nom);
                            command.Parameters.AddWithValue("@email", email);
                            command.Parameters.AddWithValue("@pseudo", pseudo);

                            // Exécuter la commande SQL pour insérer le joueur
                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                // Insertion du joueur dans la table Amateur ou Professionnel
                                using (MySqlCommand insertCommand = new MySqlCommand(insertQuery, connection))
                                {
                                    insertCommand.Parameters.AddWithValue("@num", newPlayerNumber);
                                    insertCommand.ExecuteNonQuery();
                                }

                                Console.WriteLine("\nInformations du joueur insérées avec succès !");
                            }
                            else
                            {
                                Console.WriteLine("\nErreur lors de l'insertion des informations du joueur.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Gérer les erreurs de connexion
                    Console.WriteLine("Erreur lors de la connexion à la base de données : " + ex.Message);
                }
            }
        }

        static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email && (email.EndsWith(".com") || email.EndsWith(".fr"));
            }
            catch
            {
                return false;
            }
        }

        static void StartGame(string gamePath)
        {
            if (!System.IO.File.Exists(gamePath))
            {
                Console.WriteLine($"Impossible de trouver le jeu à l'emplacement suivant : {gamePath}");
                return;
            }

            Process.Start(gamePath);
        }
    }
}
